OPC-UA Robot Integration Demo

Simulates a robot server sending data via OPC-UA.