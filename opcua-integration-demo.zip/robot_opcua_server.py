from opcua import Server
import time

server = Server()
server.set_endpoint("opc.tcp://0.0.0.0:4840/")
objects = server.get_objects_node()
robot = objects.add_object("ns=2;s=Robot", "Robot")
status = robot.add_variable("ns=2;s=Status", "Status", 0)
status.set_writable()

server.start()
try:
    while True:
        for val in range(100):
            status.set_value(val)
            time.sleep(1)
finally:
    server.stop()
