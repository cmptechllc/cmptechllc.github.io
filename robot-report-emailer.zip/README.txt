Robot Report Emailer

Reads production logs and sends a daily summary via email.