import smtplib
from email.message import EmailMessage

def send_report():
    msg = EmailMessage()
    msg['Subject'] = 'Daily Robot Report'
    msg['From'] = 'robot@yourdomain.com'
    msg['To'] = 'manager@yourdomain.com'
    msg.set_content("Production Summary:
All cells online. No alarms.")

    with smtplib.SMTP('smtp.yourdomain.com') as s:
        s.send_message(msg)

send_report()
