ABB RAPID Generator

Converts point data from CSV to .mod RAPID files.