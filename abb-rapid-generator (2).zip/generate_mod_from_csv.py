import csv

def generate_mod(csv_file):
    with open(csv_file, newline='') as f:
        reader = csv.DictReader(f)
        print("MODULE ToolPath")
        for row in reader:
            print(f"CONST robtarget p{row['Point']} := [[{row['X']},{row['Y']},{row['Z']}],[1,0,0,0],[0,0,0,0],[9E9,9E9,9E9,9E9,9E9,9E9]];")
        print("ENDMODULE")

generate_mod('points.csv')
