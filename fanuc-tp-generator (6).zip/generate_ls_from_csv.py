import csv

def generate_ls(csv_file):
    with open(csv_file, newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            print(f"J P[{row['Point']}]{row['X']},{row['Y']},{row['Z']},{row['W']},{row['P']},{row['R']}")

generate_ls('points.csv')
